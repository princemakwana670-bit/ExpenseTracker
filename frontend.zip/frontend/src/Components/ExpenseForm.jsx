function ExpenseForm() {
    return ( 
        <>
            <h2>Expense form to add expense</h2>
        </>
     );
}

export default ExpenseForm;