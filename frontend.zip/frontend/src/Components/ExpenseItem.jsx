function ExpenseItem() {
    return ( 
        <>
            <h2>Expense Item</h2>
        </>
     );
}

export default ExpenseItem;