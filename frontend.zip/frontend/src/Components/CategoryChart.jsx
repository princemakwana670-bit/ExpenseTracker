function CategoryChart() {
    return ( 
        <>
            <h2>Category Chart</h2>
        </>
     );
}

export default CategoryChart;