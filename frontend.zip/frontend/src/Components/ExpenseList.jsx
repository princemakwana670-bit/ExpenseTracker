function ExpenseList() {
    return ( 
        <>
            <h2>Expense List</h2>
        </>
     );
}

export default ExpenseList;