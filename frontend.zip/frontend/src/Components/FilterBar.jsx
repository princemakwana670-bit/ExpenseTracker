function FilterBar() {
    return ( 
        <>
            <h2>FilterBar</h2>
        </>
     );
}

export default FilterBar;