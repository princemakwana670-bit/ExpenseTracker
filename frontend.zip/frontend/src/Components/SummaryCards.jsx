function SummaryCards() {
    return ( 
        <>
            <h2>Summary Cards</h2>
        </>
     );
}

export default SummaryCards;