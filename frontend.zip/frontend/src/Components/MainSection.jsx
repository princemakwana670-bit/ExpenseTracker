function MainSection() {
    return ( 
        <>
            <h2>Main Section</h2>        
        </>
     );
}

export default MainSection;