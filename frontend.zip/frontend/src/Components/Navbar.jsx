function Navbar() {
    return ( 
        <>
            <h2>Navbar</h2>
        </>
     );
}

export default Navbar;